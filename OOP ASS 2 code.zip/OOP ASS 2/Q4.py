class BankAccount:
    interest_rate = 0.05  # Class variable

    def __init__(self, owner, balance=0):
        self.owner = owner          # Instance variable
        self.balance = balance      # Instance variable

    # Instance method to deposit money
    def deposit(self, amount):
        if amount > 0:
            self.balance += amount
            print(f"{amount} deposited. New balance: {self.balance}")
        else:
            print("Deposit amount must be positive.")

    # Instance method to withdraw money
    def withdraw(self, amount):
        if 0 < amount <= self.balance:
            self.balance -= amount
            print(f"{amount} withdrawn. New balance: {self.balance}")
        else:
            print("Withdrawal amount must be positive and cannot exceed the balance.")

    # Class method to set a new interest rate
    @classmethod
    def set_interest_rate(cls, new_rate):
        if new_rate > 0:
            cls.interest_rate = new_rate
            print(f"Interest rate updated to: {cls.interest_rate}")
        else:
            print("Interest rate must be positive.")

    # Static method to calculate future value with interest
    @staticmethod
    def calculate_future_value(principal, years):
        if principal < 0 or years < 0:
            return "Principal and years must be non-negative."
        return principal * (1 + BankAccount.interest_rate) ** years


# Creating instances of BankAccount
account1 = BankAccount("Grace", 1000)
account2 = BankAccount("James", 500)

# Using instance methods
account1.deposit(200)            # Output: 200 deposited. New balance: 1200
account1.withdraw(100)           # Output: 100 withdrawn. New balance: 1100

# Using class method
BankAccount.set_interest_rate(0.07)  # Output: Interest rate updated to: 0.07

# Using static method
future_value = BankAccount.calculate_future_value(account1.balance, 5)
print(f"Future value of {account1.owner}'s account after 5 years: {future_value:.2f}")  
# Output: Future value of Grace's account after 5 years: 1542.43