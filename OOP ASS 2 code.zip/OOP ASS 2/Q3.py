class Dog:
    # Class variable
    species = "German Shepherd"  # Shared by all instances

    def __init__(self, name, age):
        # Instance variables
        self.name = name
        self.age = age

# Creating two instances of Dog
dog1 = Dog("Scooby", 5)
dog2 = Dog("Rex", 2)

# Accessing class variable
print(f"{dog1.name} is a {dog1.species}")  # Output: Scooby is a German Shepherd
print(f"{dog2.name} is a {dog2.species}")  # Output: Rex is a German Shepherd

# Accessing instance variables
print(f"{dog1.name} is {dog1.age} years old.")  # Output: Scooby is 5 years old.
print(f"{dog2.name} is {dog2.age} years old.")  # Output: Rex is 2 years old.

# Modifying the class variable
Dog.species = "Dog"

# Checking the modified class variable
print(f"{dog1.name} is now a {dog1.species}")  # Output: Scooby is now a Dog
print(f"{dog2.name} is now a {dog2.species}")  # Output: Rex is now a Dog

