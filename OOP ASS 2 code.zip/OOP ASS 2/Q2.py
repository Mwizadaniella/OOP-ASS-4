class Person:
    def __init__(self, name, age):
        self.name = name  # Initialize the 'name' attribute
        self.age = age    # Initialize the 'age' attribute

    def display_info(self):
        print(f"Name: {self.name}, Age: {self.age}")

# Creating an object of the Person class
person1 = Person("Diana", 20)

# Accessing the object's attributes and methods
person1.display_info()  # Output: Name: Diana, Age: 20
