class Course:
    max_enrollment = 30  # Class variable

    def __init__(self, course_name):
        self.course_name = course_name  # Instance variable
        self.enrolled_students = []      # Instance variable

    def enroll_student(self, student):
        if len(self.enrolled_students) < Course.max_enrollment:
            self.enrolled_students.append(student)
            print(f"{student} has been enrolled in {self.course_name}.")
        else:
            print(f"Cannot enroll {student}. {self.course_name} is full.")

    @classmethod
    def set_max_enrollment(cls, new_limit):
        cls.max_enrollment = new_limit
        print(f"Max enrollment for all courses set to: {cls.max_enrollment}")


# Example usage
course1 = Course("Introduction to Science")
course2 = Course("Data Science Fundamentals")

course1.enroll_student("Alex")  # Output: Alex has been enrolled in Introduction to Science.
course1.enroll_student("Rita")    # Output: Rita has been enrolled in Introduction to Science.
# ...
# Enrolling more students until the limit is reached
for i in range(30):  # Adding 30 students
    course1.enroll_student(f"Student {i+1}")

# Attempt to enroll an additional student
course1.enroll_student("Charlotte")  # Output: Cannot enroll Charlotte. Introduction to Science is full.

# Changing the max enrollment for all courses
Course.set_max_enrollment(35)  # Output: Max enrollment for all courses set to: 35
