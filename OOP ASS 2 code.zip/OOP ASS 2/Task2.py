class Product:
    def __init__(self, product_name, price, quantity_in_stock):
        self.product_name = product_name
        self.price = price
        self.quantity_in_stock = quantity_in_stock

    def display_product_info(self):
        return f"Product: {self.product_name}, Price: ${self.price:.2f}, Available: {self.quantity_in_stock}"

class ShoppingCart:
    total_carts = 0  # Class variable to track the number of carts

    def __init__(self):
        self.items = []
        ShoppingCart.total_carts += 1

    def add_to_cart(self, product, quantity):
        if quantity > product.quantity_in_stock:
            print(f"Cannot add {quantity} of {product.product_name}. Only {product.quantity_in_stock} available.")
        else:
            self.items.append((product, quantity))
            product.quantity_in_stock -= quantity
            print(f"Added {quantity} of {product.product_name} to the cart.")

    def remove_from_cart(self, product):
        for item in self.items:
            if item[0] == product:
                self.items.remove(item)
                product.quantity_in_stock += item[1]  # Restore quantity to stock
                print(f"Removed {product.product_name} from the cart.")
                return
        print(f"{product.product_name} not found in cart.")

    def display_cart(self):
        if not self.items:
            print("The cart is empty.")
            return
        print("Items in the cart:")
        for product, quantity in self.items:
            print(f"{product.product_name} - Quantity: {quantity}")

    def calculate_total(self):
        total = sum(product.price * quantity for product, quantity in self.items)
        return total

# Creating Product objects
product1 = Product("Laptop", 999.99, 5)
product2 = Product("Headphones", 199.99, 10)
product3 = Product("Mouse", 49.99, 20)

# Display product information
print(product1.display_product_info())
print(product2.display_product_info())
print(product3.display_product_info())
print()

# Creating ShoppingCart instances
cart1 = ShoppingCart()
cart2 = ShoppingCart()

# Performing operations on cart1
cart1.add_to_cart(product1, 2)  # Adding 2 laptops
cart1.add_to_cart(product2, 3)  # Adding 3 headphones
cart1.display_cart()
print(f"Total amount for cart1: ${cart1.calculate_total():.2f}\n")

# Performing operations on cart2
cart2.add_to_cart(product2, 1)  # Adding 1 headphone
cart2.add_to_cart(product3, 5)   # Adding 5 mice
cart2.display_cart()
print(f"Total amount for cart2: ${cart2.calculate_total():.2f}\n")

# Removing an item from cart1
cart1.remove_from_cart(product1)  # Removing a laptop
cart1.display_cart()
print(f"Total amount for cart1 after removal: ${cart1.calculate_total():.2f}\n")

# Final state of the products
print("Final stock levels:")
print(product1.display_product_info())
print(product2.display_product_info())
print(product3.display_product_info())
